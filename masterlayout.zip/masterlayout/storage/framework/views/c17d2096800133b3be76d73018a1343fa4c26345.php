<!DOCTYPE html>
<html lang="en">

<head>

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <header>
                <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </header>
            <div class="col-2"></div>
            <div class="col-10">
                <?php echo $__env->yieldContent('content'); ?>
                 
            </div>
            <footer class="row">
                <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </footer>
        </div>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\webmingoproject\masterlayout\resources\views/layouts/index.blade.php ENDPATH**/ ?>