<!DOCTYPE html>
<html lang="en">

<head>

    @include('includes.head')
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <header>
                @include('includes.sidebar')
            </header>
            <div class="col-2"></div>
            <div class="col-10">
                @yield('content')
                 
            </div>
            <footer class="row">
                @include('includes.footer')
            </footer>
        </div>
    </div>
</body>

</html>
