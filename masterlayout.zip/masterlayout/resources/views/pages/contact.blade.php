@extends('layouts.index')

@section('content')
<h1>welcome to page</h1>

<div class="container-fluid">
    <h2>Contact page</h2>
    <div class="row">
        <div class="col-12 bg-info">contact page
            <div class="col-6">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam omnis molestiae expedita dolor! Soluta rerum cumque repellat adipisci ab architecto enim, aut totam, dolore molestiae voluptatem in atque minus quam.
            </div>
        </div>
    </div>
</div>

@endsection
